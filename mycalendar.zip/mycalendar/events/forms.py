from django.contrib.auth.forms import UserCreationForm
from django import forms
from .models import CustomUser, Event  # Используем кастомную модель пользователя

from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.contrib.auth.models import User

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User  # Используем стандартную модель User
        fields = ['username', 'email', 'password1', 'password2']  # Включаем поля для имени, почты и пароля

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("A user with this email already exists.")
        return email
class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ['title', 'description', 'start_event_time', 'end_event_time']  # Поля для создания события