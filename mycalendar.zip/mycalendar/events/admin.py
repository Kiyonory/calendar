from django.contrib import admin
from .models import CustomUser, Calendar, Event

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ['username', 'email', 'name']

@admin.register(Calendar)
class CalendarAdmin(admin.ModelAdmin):
    list_display = ['user', 'date_of_creation']

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ['title', 'start_event_time', 'end_event_time', 'calendar']