from django.db import models
from django.conf import settings  # Импортируем настройки для использования кастомной модели пользователя


class CustomUser(models.Model):  # Вместо AbstractUser, создаем свою модель, так как AbstractUser уже заменен
    username = models.CharField(max_length=150, unique=True)  # Добавляем поле username, если используем CustomUser
    email = models.EmailField(unique=True)  # Уникальный email
    name = models.CharField(max_length=100, null=True, blank=True)  # Имя пользователя
    password = models.CharField(max_length=255)  # Пароль (можно использовать встроенное поле для пароля)
    USERNAME_FIELD = 'email'  # Указываем, что аутентификация будет происходить по email
    REQUIRED_FIELDS = ['username', 'name']  # Поля, которые нужно запросить при создании суперпользователя
    def str(self):
        return self.username  # Отображение имени пользователя в админке и других местах

    # Добавление методов, если необходимо (например, для пароля)


from django.contrib.auth.models import User  # Импортируем стандартную модель User
from django.db import models

class Calendar(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Связь с стандартной моделью User
    link = models.TextField()  # Уникальная ссылка для календаря
    date_of_creation = models.DateTimeField(auto_now_add=True)  # Дата создания календаря

    def str(self):
        return f"Calendar of {self.user.username}"


class Event(models.Model):
    title = models.CharField(max_length=255)  # Название события
    description = models.TextField(blank=True, null=True)  # Описание
    start_event_time = models.DateTimeField()  # Время начала
    end_event_time = models.DateTimeField()  # Время окончания
    calendar = models.ForeignKey(Calendar, on_delete=models.CASCADE)  # Связь с календарем

    def str(self):
        return self.title