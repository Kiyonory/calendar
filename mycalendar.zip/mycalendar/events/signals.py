from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import CustomUser, Calendar

@receiver(post_save, sender=CustomUser)
def create_user_calendar(sender, instance, created, **kwargs):
    if created:
        # Создание нового календаря для пользователя
        Calendar.objects.create(
            link=f'calendar-{instance.id}',  # Генерация ссылки на календарь
            user=instance  # Привязка календаря к пользователю
        )