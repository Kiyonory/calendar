from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm, EventForm
from django.contrib.auth.models import User  # Импортируем стандартную модель User
from .models import Calendar
import uuid
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .forms import CustomUserCreationForm, EventForm
from .models import Calendar

unique_link = str(uuid.uuid4())  # Генерация уникальной ссылки

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()  # Сохраняем пользователя
            # После того как пользователь сохранен, создаем календарь для него
            if not Calendar.objects.filter(user=user).exists():
                Calendar.objects.create(user=user, link=unique_link)  # Создание календаря для нового пользователя
            return redirect('login')  # Перенаправляем на страницу входа
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)  # Входим в систему
                return redirect('home')  # Перенаправляем на страницу home
    else:
        form = AuthenticationForm()

    return render(request, 'login.html', {'form': form})
from django.shortcuts import render
from .models import Event
from django.utils import timezone  # Для фильтрации событий, которые еще не прошли


def home(request):
    if request.user.is_authenticated:
        # Получаем календарь пользователя
        user_calendar = Calendar.objects.get(user=request.user)

        # Получаем все события, связанные с этим календарем
        events = Event.objects.filter(calendar=user_calendar).order_by('start_event_time')  # Можно добавить сортировку

        return render(request, 'home.html', {'events': events})
    else:
        return redirect('login')  # Перенаправляем на страницу входа, если пользователь не залогинен
def create_event(request):
    if request.user.is_authenticated:  # Проверяем, что пользователь залогинен
        user_calendar = Calendar.objects.get(user=request.user)  # Получаем календарь пользователя
        if request.method == 'POST':
            form = EventForm(request.POST)
            if form.is_valid():
                event = form.save(commit=False)
                event.calendar = user_calendar  # Связываем событие с календарем пользователя
                event.save()
                return redirect('home')  # Перенаправляем на главную страницу или страницу с событиями
        else:
            form = EventForm()
        return render(request, 'create_event.html', {'form': form})
    else:
        return redirect('login')  # Перенаправляем на страницу входа, если пользователь не залогинен
from django.shortcuts import render, redirect, get_object_or_404
from .models import Event
from django.contrib.auth.decorators import login_required

@login_required
def delete_event(request, event_id):
    event = get_object_or_404(Event, id=event_id)

    # Проверяем, что событие принадлежит текущему пользователю
    if event.calendar.user == request.user:
        event.delete()  # Удаляем событие
        return redirect('home')  # Перенаправляем на главную страницу после удаления
    else:
        return redirect('home')  # Если событие не принадлежит пользователю, просто перенаправляем
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Event
from .forms import EventForm
from django.contrib import messages

@login_required
def edit_event(request, event_id):
    # Получаем событие, которое пользователь хочет изменить
    event = get_object_or_404(Event, id=event_id)

    # Проверяем, что событие принадлежит календарю пользователя
    if event.calendar.user != request.user:
        messages.error(request, "You are not authorized to edit this event.")
        return redirect('home')

    if request.method == 'POST':
        form = EventForm(request.POST, instance=event)  # Передаем существующее событие для редактирования
        if form.is_valid():
            form.save()  # Сохраняем изменения
            messages.success(request, "Event updated successfully!")
            return redirect('home')  # Перенаправляем на главную страницу
    else:
        form = EventForm(instance=event)  # Заполняем форму текущими данными события

    return render(request, 'edit_event.html', {'form': form})