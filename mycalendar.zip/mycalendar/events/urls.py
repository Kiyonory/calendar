from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),  # Указываем адрес для регистрации
    path('login/', views.login_view, name='login'),  # Страница входа
    path('home/', views.home, name='home'),
    path('create-event/', views.create_event, name='create_event'),  # Маршрут для создания событий
    path('delete-event/<int:event_id>/', views.delete_event, name='delete_event'),  # Маршрут для удаления события
    path('event/<int:event_id>/edit/', views.edit_event, name='edit_event'),

]