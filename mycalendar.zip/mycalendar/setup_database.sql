-- Создание базы данных CALENDAR1, если она не существует
DO
$$
BEGIN
   -- Проверка, существует ли база данных
   IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'CALENDAR1') THEN
      -- Создание базы данных
      EXECUTE 'CREATE DATABASE "CALENDAR1"';
   END IF;
END
$$;