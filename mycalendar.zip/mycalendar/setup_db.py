import psycopg2
import sys
from psycopg2 import sql
def create_database(host, port, user, password, database_name):
    try:
        # Соединение с PostgreSQL (используем соединение с postgres)
        conn = psycopg2.connect(
            dbname='postgres',  # Используем базу данных postgres для создания новой
            user=user,
            password=password,
            host=host,
            port=port
        )
        conn.autocommit = True  # Для выполнения команд, таких как CREATE DATABASE, нужно отключить транзакции
        cur = conn.cursor()

        # Создание базы данных
        cur.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(database_name)))
        cur.close()
        conn.close()
        print(f"База данных '{database_name}' успешно создана.")
    except Exception as e:
        print(f"Ошибка при создании базы данных: {e}")
        sys.exit(1)

def execute_sql_script(host, port, user, password, database_name, script_path):
    try:
        # Подключаемся к базе данных, которую только что создали
        conn = psycopg2.connect(
            dbname=database_name,
            user=user,
            password=password,
            host=host,
            port=port
        )
        cur = conn.cursor()

        # Чтение и выполнение SQL-скрипта
        with open(script_path, 'r') as file:
            sql_script = file.read()
        cur.execute(sql_script)
        conn.commit()
        cur.close()
        conn.close()
        print("SQL-скрипт успешно выполнен.")
    except Exception as e:
        print(f"Ошибка при выполнении SQL-скрипта: {e}")
        sys.exit(1)

if __name__ == '__main__':
    # Ввод данных пользователем
    host = input("Введите хост (по умолчанию localhost): ") or "localhost"
    port = input("Введите порт (по умолчанию 5432): ") or "5432"
    user = input("Введите имя пользователя (по умолчанию postgres): ") or "postgres"
    password = input("Введите пароль пользователя: ")
    database_name = "CALENDAR1"
    script_path = input("Введите путь к SQL-скрипту (по умолчанию setup_database.sql): ") or "setup_database.sql"

    create_database(host, port, user, password, database_name)
    execute_sql_script(host, port, user, password, database_name, script_path)